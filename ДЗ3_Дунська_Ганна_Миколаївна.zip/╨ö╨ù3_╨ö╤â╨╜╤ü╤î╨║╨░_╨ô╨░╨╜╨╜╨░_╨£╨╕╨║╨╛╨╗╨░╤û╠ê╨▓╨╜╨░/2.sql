SELECT name, phone 
FROM mydb.shippers;