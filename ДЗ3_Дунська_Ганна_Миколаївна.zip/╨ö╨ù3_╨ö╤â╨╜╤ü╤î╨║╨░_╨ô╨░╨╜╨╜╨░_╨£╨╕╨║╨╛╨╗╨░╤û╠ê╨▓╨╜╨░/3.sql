SELECT AVG(price) as average_price,
MAX(price) as max_price,
MIN(price) as min_price
FROM mydb.products;