SELECT COUNT(*) AS product_count
FROM mydb.products
WHERE price >= 20 AND price <= 100